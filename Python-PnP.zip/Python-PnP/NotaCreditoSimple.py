# PASO 1: Consiste en importar la libreria
import PnP

class FacturaSimple():
    #PASO 3: Instanciar la libreria y definir los parametros por defecto que utilizaremos
    Printer = PnP.PnP()
    PORT = "COM12"                                           # Definimos el puerto serial donde esta conectada la impresora fiscal
    PortOpen = False
    Respuesta = False

    try:
        #PASO 4: Utilizar los Métodos y atributos que ofrece la libreria
        PortOpen = Printer.OpenPnP(PORT)
        if PortOpen:
            
            print("Puerto: "+ PORT + " ABIERTO")

            input("Presione enter para continuar ...")
#Abre nota de credito. Revisar protocolo fiscal para determinar campos

            Respuesta = Printer.SendCmd("@|PRUEBA|J000000000|00000001|EOG0123654|05052023|150400|D")
            if not Respuesta: print("!!! Comando No Aceptado: ")
            else: print("*** Comando Enviado: Abre Nota de credito" )
#renglon
            Respuesta = Printer.SendCmd("B|Producto|1000|1000|1600|M")
            if not Respuesta: print("Comando No Aceptado: ")
            else: print("*** Comando Enviado: Renglon")
#Texto Fiscal
            Respuesta = Printer.SendCmd("A|Texto adicional")
            if not Respuesta: print("Comando No Aceptado: ")
            else: print("*** Comando Enviado: Texto Fiscal")
#cierra factura
            Respuesta = Printer.SendCmd("E|T")
            if not Respuesta: print("Comando No Aceptado: ")
            else: print("*** Comando Enviado: Cierre" )

            Printer.ClosePnP()
            
            print("")
            print("###############")
            print("")
            #input("Presione enter para Salir ..." 
            
        else:
            print("NO SE PUDO ESTABLECER COMUNICACION CON LA IMPRESORA")
            print("PUERTO: " + PORT + " CERRADO")
            print("")
            print("###############")
            print("")
   
    except Exception as e: 
      print("OCURRIO UNA EXCEPCION: \nDetalles del Error: \n\ ", type(e).__name__)