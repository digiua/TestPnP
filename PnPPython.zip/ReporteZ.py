import PnP

class ReporteX():
    Printer = PnP.PnP()
    PORT = "COM12"  
    try:
        PortOpen = Printer.OpenPnP(PORT)
        if PortOpen: 
            print("Puerto: "+ PORT + " ABIERTO")
            Printer.SendCmd('9|Z|T')
            Printer.ClosePnP()

    except Exception as e: 
      print("OCURRIO UNA EXCEPCION: \nDetalles del Error: \n\ ", e)