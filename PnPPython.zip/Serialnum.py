import PnP
import time

class Serial():
    Printer = PnP.PnP()
    PORT = "COM12"  
    try:
        PortOpen = Printer.OpenPnP(PORT)
        if PortOpen: 
            print("Puerto: "+ PORT + " ABIERTO PIDE SERIAL:")
            # print(Printer.SendCmd("8|N"))
            print(Printer.SendCmd("\x80|"))
            Printer.ClosePnP()
    except Exception as e: 
      print("OCURRIO UNA EXCEPCION: \nDetalles del Error: \n\ ", e)