import PnP
import time

class Status():
    Printer = PnP.PnP()
    PORT = "COM12"  
    try:
        PortOpen = Printer.OpenPnP(PORT)
        if PortOpen: 
            print("Puerto: "+ PORT + " ABIERTO PIDE SERIAL:")
            print(Printer.SendCmd("8|N"))
            Printer.ClosePnP()
    except Exception as e: 
      print("OCURRIO UNA EXCEPCION: \nDetalles del Error: \n\ ", e)